﻿scmagnify.plotting.GRNVisualizer
================================

.. currentmodule:: scmagnify.plotting

.. add toctree option to make autodoc generate the pages

.. autoclass:: GRNVisualizer







Methods table
~~~~~~~~~~~~~

.. autosummary::

    ~GRNVisualizer.add_continuous_mapping
    ~GRNVisualizer.example_interactive_plot
    ~GRNVisualizer.export
    ~GRNVisualizer.load_network
    ~GRNVisualizer.plot
    ~GRNVisualizer.prepare_network









Methods
~~~~~~~



.. automethod:: GRNVisualizer.add_continuous_mapping

.. automethod:: GRNVisualizer.example_interactive_plot

.. automethod:: GRNVisualizer.export

.. automethod:: GRNVisualizer.load_network

.. automethod:: GRNVisualizer.plot

.. automethod:: GRNVisualizer.prepare_network


