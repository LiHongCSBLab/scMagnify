﻿scmagnify.GRNMuData
===================

.. currentmodule:: scmagnify

.. add toctree option to make autodoc generate the pages

.. autoclass:: GRNMuData



Attributes table
~~~~~~~~~~~~~~~~

.. autosummary::

    ~GRNMuData.axis
    ~GRNMuData.filename
    ~GRNMuData.isbacked
    ~GRNMuData.n_mod
    ~GRNMuData.n_obs
    ~GRNMuData.n_var
    ~GRNMuData.n_vars
    ~GRNMuData.obs
    ~GRNMuData.obs_names
    ~GRNMuData.obsm
    ~GRNMuData.obsmap
    ~GRNMuData.obsp
    ~GRNMuData.shape
    ~GRNMuData.var
    ~GRNMuData.var_names
    ~GRNMuData.varm
    ~GRNMuData.varmap
    ~GRNMuData.varp





Methods table
~~~~~~~~~~~~~

.. autosummary::

    ~GRNMuData.copy
    ~GRNMuData.filter
    ~GRNMuData.obs_keys
    ~GRNMuData.obs_names_make_unique
    ~GRNMuData.obs_vector
    ~GRNMuData.obsm_keys
    ~GRNMuData.strings_to_categoricals
    ~GRNMuData.to_cyto
    ~GRNMuData.to_matrix
    ~GRNMuData.to_nx
    ~GRNMuData.uns_keys
    ~GRNMuData.update
    ~GRNMuData.update_obs
    ~GRNMuData.update_var
    ~GRNMuData.var_keys
    ~GRNMuData.var_names_make_unique
    ~GRNMuData.var_vector
    ~GRNMuData.varm_keys
    ~GRNMuData.write
    ~GRNMuData.write_h5mu
    ~GRNMuData.write_zarr





Attributes
~~~~~~~~~~



.. autoattribute:: GRNMuData.axis

.. autoattribute:: GRNMuData.filename

.. autoattribute:: GRNMuData.isbacked

.. autoattribute:: GRNMuData.n_mod

.. autoattribute:: GRNMuData.n_obs

.. autoattribute:: GRNMuData.n_var

.. autoattribute:: GRNMuData.n_vars

.. autoattribute:: GRNMuData.obs

.. autoattribute:: GRNMuData.obs_names

.. autoattribute:: GRNMuData.obsm

.. autoattribute:: GRNMuData.obsmap

.. autoattribute:: GRNMuData.obsp

.. autoattribute:: GRNMuData.shape

.. autoattribute:: GRNMuData.var

.. autoattribute:: GRNMuData.var_names

.. autoattribute:: GRNMuData.varm

.. autoattribute:: GRNMuData.varmap

.. autoattribute:: GRNMuData.varp






Methods
~~~~~~~



.. automethod:: GRNMuData.copy

.. automethod:: GRNMuData.filter

.. automethod:: GRNMuData.obs_keys

.. automethod:: GRNMuData.obs_names_make_unique

.. automethod:: GRNMuData.obs_vector

.. automethod:: GRNMuData.obsm_keys

.. automethod:: GRNMuData.strings_to_categoricals

.. automethod:: GRNMuData.to_cyto

.. automethod:: GRNMuData.to_matrix

.. automethod:: GRNMuData.to_nx

.. automethod:: GRNMuData.uns_keys

.. automethod:: GRNMuData.update

.. automethod:: GRNMuData.update_obs

.. automethod:: GRNMuData.update_var

.. automethod:: GRNMuData.var_keys

.. automethod:: GRNMuData.var_names_make_unique

.. automethod:: GRNMuData.var_vector

.. automethod:: GRNMuData.varm_keys

.. automethod:: GRNMuData.write

.. automethod:: GRNMuData.write_h5mu

.. automethod:: GRNMuData.write_zarr


