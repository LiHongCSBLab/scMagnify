﻿scmagnify.plotting.distplot
===========================

.. currentmodule:: scmagnify.plotting

.. autofunction:: distplot