﻿scmagnify.plotting.trendplot
============================

.. currentmodule:: scmagnify.plotting

.. autofunction:: trendplot