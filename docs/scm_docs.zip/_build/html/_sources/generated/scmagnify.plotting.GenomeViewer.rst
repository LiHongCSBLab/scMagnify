﻿scmagnify.plotting.GenomeViewer
===============================

.. currentmodule:: scmagnify.plotting

.. add toctree option to make autodoc generate the pages

.. autoclass:: GenomeViewer







Methods table
~~~~~~~~~~~~~

.. autosummary::

    ~GenomeViewer.add_motifs
    ~GenomeViewer.plot









Methods
~~~~~~~



.. automethod:: GenomeViewer.add_motifs

.. automethod:: GenomeViewer.plot


