﻿scmagnify.MAGNI
===============

.. currentmodule:: scmagnify

.. add toctree option to make autodoc generate the pages

.. autoclass:: MAGNI







Methods table
~~~~~~~~~~~~~

.. autosummary::

    ~MAGNI.estimate_lags
    ~MAGNI.load
    ~MAGNI.regulation_inference
    ~MAGNI.save
    ~MAGNI.train









Methods
~~~~~~~



.. automethod:: MAGNI.estimate_lags

.. automethod:: MAGNI.load

.. automethod:: MAGNI.regulation_inference

.. automethod:: MAGNI.save

.. automethod:: MAGNI.train


