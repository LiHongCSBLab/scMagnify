﻿scmagnify.tools.infer\_signal\_pairs
====================================

.. currentmodule:: scmagnify.tools

.. autofunction:: infer_signal_pairs