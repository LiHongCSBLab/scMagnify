﻿scmagnify.tools.extract\_regfactor\_genes
=========================================

.. currentmodule:: scmagnify.tools

.. autofunction:: extract_regfactor_genes