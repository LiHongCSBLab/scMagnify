﻿scmagnify.tools.RegDecomp
=========================

.. currentmodule:: scmagnify.tools

.. add toctree option to make autodoc generate the pages

.. autoclass:: RegDecomp



Attributes table
~~~~~~~~~~~~~~~~

.. autosummary::

    ~RegDecomp.get_tensor





Methods table
~~~~~~~~~~~~~

.. autosummary::

    ~RegDecomp.compute_activity
    ~RegDecomp.cp_decomposition
    ~RegDecomp.normalization
    ~RegDecomp.rename_regfactors
    ~RegDecomp.tucker_decomposition





Attributes
~~~~~~~~~~



.. autoattribute:: RegDecomp.get_tensor






Methods
~~~~~~~



.. automethod:: RegDecomp.compute_activity

.. automethod:: RegDecomp.cp_decomposition

.. automethod:: RegDecomp.normalization

.. automethod:: RegDecomp.rename_regfactors

.. automethod:: RegDecomp.tucker_decomposition


