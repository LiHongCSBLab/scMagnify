﻿scmagnify.tools.connect\_peaks\_genes
=====================================

.. currentmodule:: scmagnify.tools

.. autofunction:: connect_peaks_genes