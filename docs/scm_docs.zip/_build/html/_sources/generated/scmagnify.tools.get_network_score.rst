﻿scmagnify.tools.get\_network\_score
===================================

.. currentmodule:: scmagnify.tools

.. autofunction:: get_network_score