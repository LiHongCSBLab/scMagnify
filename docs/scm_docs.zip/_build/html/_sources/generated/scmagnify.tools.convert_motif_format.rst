﻿scmagnify.tools.convert\_motif\_format
======================================

.. currentmodule:: scmagnify.tools

.. autofunction:: convert_motif_format