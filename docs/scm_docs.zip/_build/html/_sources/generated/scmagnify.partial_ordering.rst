﻿scmagnify.partial\_ordering
===========================

.. currentmodule:: scmagnify

.. autofunction:: partial_ordering