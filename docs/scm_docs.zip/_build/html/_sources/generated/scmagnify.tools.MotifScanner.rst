﻿scmagnify.tools.MotifScanner
============================

.. currentmodule:: scmagnify.tools

.. add toctree option to make autodoc generate the pages

.. autoclass:: MotifScanner







Methods table
~~~~~~~~~~~~~

.. autosummary::

    ~MotifScanner.add_custom_motif
    ~MotifScanner.export_motifs
    ~MotifScanner.import_motifs
    ~MotifScanner.match
    ~MotifScanner.show_motif_databases









Methods
~~~~~~~



.. automethod:: MotifScanner.add_custom_motif

.. automethod:: MotifScanner.export_motifs

.. automethod:: MotifScanner.import_motifs

.. automethod:: MotifScanner.match

.. automethod:: MotifScanner.show_motif_databases


