﻿scmagnify.tools.FuncEnrich
==========================

.. currentmodule:: scmagnify.tools

.. add toctree option to make autodoc generate the pages

.. autoclass:: FuncEnrich







Methods table
~~~~~~~~~~~~~

.. autosummary::

    ~FuncEnrich.add_genesets
    ~FuncEnrich.filter_genesets
    ~FuncEnrich.get_overlap_genes
    ~FuncEnrich.run_ora









Methods
~~~~~~~



.. automethod:: FuncEnrich.add_genesets

.. automethod:: FuncEnrich.filter_genesets

.. automethod:: FuncEnrich.get_overlap_genes

.. automethod:: FuncEnrich.run_ora


