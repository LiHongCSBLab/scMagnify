﻿scmagnify.tools.lineage\_classifer
==================================

.. currentmodule:: scmagnify.tools

.. autofunction:: lineage_classifer