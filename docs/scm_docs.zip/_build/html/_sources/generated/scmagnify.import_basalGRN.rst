﻿scmagnify.import\_basalGRN
==========================

.. currentmodule:: scmagnify

.. autofunction:: import_basalGRN