﻿scmagnify.plotting.barplot
==========================

.. currentmodule:: scmagnify.plotting

.. autofunction:: barplot