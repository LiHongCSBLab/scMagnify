﻿scmagnify.plotting.heatmap
==========================

.. currentmodule:: scmagnify.plotting

.. autofunction:: heatmap