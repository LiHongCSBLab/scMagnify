﻿scmagnify.chromatin\_constraint
===============================

.. currentmodule:: scmagnify

.. autofunction:: chromatin_constraint