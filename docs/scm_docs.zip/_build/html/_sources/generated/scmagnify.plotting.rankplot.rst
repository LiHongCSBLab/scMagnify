﻿scmagnify.plotting.rankplot
===========================

.. currentmodule:: scmagnify.plotting

.. autofunction:: rankplot