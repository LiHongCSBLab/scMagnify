﻿scmagnify.tools.select\_paga\_path
==================================

.. currentmodule:: scmagnify.tools

.. autofunction:: select_paga_path